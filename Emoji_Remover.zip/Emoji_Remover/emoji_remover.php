<?php
/*
Plugin Name: emoji_remover
Description: Emoji Remover
Version: 1.0.2
*/
/* Start Adding Functions Below this Line */


/* START Function Remove Emoji Stuff */

remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
remove_action( 'admin_print_scripts', 'print_emoji_detection_script' );
remove_action( 'wp_print_styles', 'print_emoji_styles' );
remove_action( 'admin_print_styles', 'print_emoji_styles' );

/* END Function Emoji Remover Stuff */

/* Stop Adding Functions Below this Line */
?>
